from __future__ import annotations

import subprocess
import sys
import time

import cv2
import numpy as np

from config import AppConfig
from detector import Detector


class App:
    def __init__(self, cfg: AppConfig, detector: Detector) -> None:
        self.cfg = cfg
        self.detector = detector

    def run(self, package: str) -> int:
        if self._adb("get-state", timeout=5).decode().strip() != "device":
            sys.exit("Устройство не готово. Проверьте кабель и USB-отладку.")

        launch = self._run_adb(
            "shell", "monkey", "-p", package,
            "-c", "android.intent.category.LAUNCHER", "1",
        )
        text = (launch.stdout + launch.stderr).decode("utf-8", errors="replace").lower()
        if launch.returncode != 0 or "no activities found" in text:
            sys.exit(f"Не удалось запустить '{package}'. Проверьте имя пакета.")

        deadline = time.monotonic() + self.cfg.timeout_sec
        while time.monotonic() < deadline:
            image = self._screenshot()
            point = self.detector.find_button(image)
            if point is not None:
                x, y = point
                self._adb("shell", "input", "tap", str(x), str(y), timeout=5)
                print(f"Кнопка цвета '{self.detector.color}' найдена и нажата: ({x}, {y})")
                return 0
            time.sleep(self.cfg.poll_interval_sec)

        print(
            f"Кнопка цвета '{self.detector.color}' не найдена на экране приложения "
            f"'{package}' за {self.cfg.timeout_sec:.0f} секунд."
        )
        return 0

    def _run_adb(self, *args: str, timeout: float | None = None) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                ["adb", *args],
                capture_output=True,
                timeout=timeout or self.cfg.adb_timeout_sec,
            )
        except FileNotFoundError:
            sys.exit("adb не найден. Установите Android platform-tools и добавьте в PATH.")
        except subprocess.TimeoutExpired:
            sys.exit(f"adb не ответил: adb {' '.join(args)}")

    def _adb(self, *args: str, timeout: float | None = None) -> bytes:
        result = self._run_adb(*args, timeout=timeout)
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="replace").strip()
            sys.exit(f"adb ошибка ({result.returncode}): {err or ' '.join(args)}")
        return result.stdout

    def _screenshot(self) -> np.ndarray:
        raw = self._adb("exec-out", "screencap", "-p")
        image = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image is None:
            sys.exit("Не удалось получить скриншот с устройства.")
        return image
