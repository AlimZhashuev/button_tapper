from __future__ import annotations

import argparse
from pathlib import Path


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Запускает приложение на устройстве adb и нажимает кнопку заданного цвета."
    )
    parser.add_argument("package", help="Имя пакета, например com.android.settings")
    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        default=Path(__file__).with_name("config.yml"),
        help="Путь к YAML-конфигу (по умолчанию config.yml рядом со скриптом)",
    )
    parser.add_argument(
        "--color",
        help="Цвет кнопки: green, red, blue, yellow, orange, purple (перекрывает конфиг)",
    )
    return parser.parse_args(argv)
