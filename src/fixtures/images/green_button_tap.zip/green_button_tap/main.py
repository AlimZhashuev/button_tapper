from __future__ import annotations

import sys

from app import App
from config import load_config
from detector import Detector
from parser import parse_args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    cfg = load_config(args.config)
    if args.color:
        cfg.detector.color = args.color
        cfg.detector.hsv = None
    try:
        detector = Detector(cfg.detector)
    except ValueError as exc:
        sys.exit(str(exc))
    application = App(cfg, detector)
    return application.run(args.package)


if __name__ == "__main__":
    sys.exit(main())
