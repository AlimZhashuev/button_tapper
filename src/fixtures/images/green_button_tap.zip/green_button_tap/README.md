# green-button-tap

Скрипт запускает Android-приложение по имени пакета, ищет на экране кнопку
заданного цвета и нажимает её. Без Appium: только `adb` и OpenCV.

## Требования

- Python 3.12
- `adb` в `PATH`
- устройство с USB-отладкой

## Установка

```bash
pip install -e .
# или
pip install -r requirements.txt
```

## Запуск

```bash
python main.py com.example.app
python main.py com.example.app --color red
python main.py com.example.app -c config.yml --color blue
```

Цвет задаётся в `config.yml` (`detector.color`) или флагом `--color`.
Пресеты: `green`, `red`, `blue`, `yellow`, `orange`, `purple`.
Свой оттенок — через `detector.hsv` в YAML (можно несколько диапазонов).
Если конфига нет — зелёный и остальные дефолты из `config.py`.
За 10 секунд скрипт ищет самую большую область выбранного цвета и тапает в центр.
Если кнопки нет — печатает сообщение и выходит с кодом 0.
