from __future__ import annotations

import cv2
import numpy as np

from config import DetectorConfig, hsv_ranges_for


class Detector:
    def __init__(self, cfg: DetectorConfig) -> None:
        self.color = cfg.color
        self.min_button_area = cfg.min_button_area
        self._ranges = [
            (
                np.array([r.h_low, r.s_low, r.v_low], dtype=np.uint8),
                np.array([r.h_high, r.s_high, r.v_high], dtype=np.uint8),
            )
            for r in hsv_ranges_for(cfg)
        ]

    def find_button(self, image: np.ndarray) -> tuple[int, int] | None:
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for low, high in self._ranges:
            mask = cv2.bitwise_or(mask, cv2.inRange(hsv, low, high))
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None
        contour = max(contours, key=cv2.contourArea)
        if cv2.contourArea(contour) < self.min_button_area:
            return None
        x, y, w, h = cv2.boundingRect(contour)
        return x + w // 2, y + h // 2
